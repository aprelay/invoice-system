// Popup JavaScript
document.addEventListener('DOMContentLoaded', () => {
  // Get references to elements
  const emailCountEl = document.getElementById('email-count');
  const emailPreviewEl = document.getElementById('email-preview');
  const toggleEnabledEl = document.getElementById('toggle-enabled');
  const viewEmailsBtn = document.getElementById('view-emails-btn');
  const copyAllBtn = document.getElementById('copy-all-btn');
  const clearBtn = document.getElementById('clear-btn');
  
  // Load data from content script
  function loadData() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getData' }, (response) => {
          if (response) {
            updateUI(response.emails, response.enabled);
          }
        });
      }
    });
  }
  
  // Update UI
  function updateUI(emails, enabled) {
    emailCountEl.textContent = emails.length;
    toggleEnabledEl.checked = enabled;
    
    // Show preview of first 5 emails
    if (emails.length > 0) {
      emailPreviewEl.innerHTML = emails.slice(0, 5).map(email => `
        <div class="email-item">
          <span>${email}</span>
          <button class="copy-btn" data-email="${email}">Copy</button>
        </div>
      `).join('');
      
      if (emails.length > 5) {
        emailPreviewEl.innerHTML += `
          <div style="text-align: center; padding: 10px; color: #718096; font-size: 12px;">
            +${emails.length - 5} more emails
          </div>
        `;
      }
      
      // Add copy listeners
      document.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const email = e.target.getAttribute('data-email');
          copyToClipboard(email);
          showNotification('✅ Copied!');
        });
      });
    } else {
      emailPreviewEl.innerHTML = `
        <div style="text-align: center; padding: 30px; color: #a0aec0;">
          No emails found yet.<br>
          Start scrolling on the page!
        </div>
      `;
    }
  }
  
  // Copy to clipboard
  function copyToClipboard(text) {
    navigator.clipboard.writeText(text);
  }
  
  // Show notification
  function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 10px;
      right: 10px;
      background: #48bb78;
      color: white;
      padding: 10px 15px;
      border-radius: 6px;
      font-size: 12px;
      z-index: 9999;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => notification.remove(), 2000);
  }
  
  // Toggle enabled/disabled
  toggleEnabledEl.addEventListener('change', (e) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'setEnabled',
          enabled: e.target.checked
        });
      }
    });
  });
  
  // View all emails
  viewEmailsBtn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'showPopup' });
        window.close();
      }
    });
  });
  
  // Copy all emails
  copyAllBtn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getData' }, (response) => {
          if (response && response.emails.length > 0) {
            copyToClipboard(response.emails.join('\n'));
            showNotification(`✅ Copied ${response.emails.length} emails!`);
          }
        });
      }
    });
  });
  
  // Clear emails
  clearBtn.addEventListener('click', () => {
    if (confirm('Clear all extracted emails?')) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'clearEmails' }, () => {
            loadData();
            showNotification('🗑️ Emails cleared!');
          });
        }
      });
    }
  });
  
  // Initial load
  loadData();
  
  // Refresh every 2 seconds
  setInterval(loadData, 2000);
});
